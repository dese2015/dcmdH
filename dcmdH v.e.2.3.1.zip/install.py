# install.py - standalone installer for dcmdH (replaces setup.py)
#
# Usage:
#     python install.py                      -> asks where to install
#     python install.py "C:\\some\\folder"   -> installs without asking
#     python install.py "C:\\folder" --yes   -> also add the folder to PATH
#     python install.py --version 5.1.1      -> download that exact version
#     python install.py --url https://...    -> download from another URL
#
# It creates <install>\\dcmdH\\ with the full dcmdH program:
#     dcmdH.py, Startup.py, dcmdH_check.py, dcmdH.cmd, dcmdH.spec,
#     Version.txt, READ ME.txt, dcmdH icon.ico, SaveFuncs.txt,
#     SkipCheck.txt, upload_build.py
#     and the compiled build dist\\dcmdH\\ (dcmdH.exe + _internal) when present.
#
# and also writes SkipCheck.txt, so dcmdH starts normally instead of
# opening its own installer - exactly the job setup.py's SkipCheck.txt did.
#
# Two modes:
#   1. Local mode - run it inside the dcmdH folder (or next to an
#      extracted dcmdH zip): it copies the files it finds next to itself.
#   2. Standalone mode - when install.py is the ONLY file you have,
#      it downloads the official dcmdH build zip from GitHub and
#      installs that. One small file is enough for a full install.

import os
import shutil
import subprocess
import sys
import ssl
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

# ---------------- download source (edit when you release a new version) --
OWNER = 'dese2015'          # GitHub user / org
REPO = 'dcmdH'              # repository (must be PUBLIC, like upload_build.py)
BRANCH = 'main'
# Version used when install.py has no Version.txt next to it (standalone).
DEFAULT_VERSION = '5.1.1'
RAW_BASE = f'https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCH}/'

# ---------------- what gets installed -------------------------------
APP_FOLDER = 'dcmdH'                        # install folder name
BUILD_DIR = os.path.join('dist', 'dcmdH')   # compiled build location
# Everything the dcmdH zip ships at its root (upload_build.py EXTRA_FILES
# minus install.py). Only files that exist next to install.py are copied.
PAYLOAD_FILES = [
    'dcmdH.py', 'Startup.py', 'dcmdH_check.py', 'upload_build.py',
    'dcmdH.cmd', 'dcmdH.spec', 'Version.txt', 'dcmdH icon.ico',
    'READ ME.txt', 'SkipCheck.txt', 'SaveFuncs.txt',
]

# ---------------- colors ----------------
RED = '\033[91m'
GREEN = '\033[92m'
BLUE = '\033[94m'
RESET = '\033[0m'


def _enable_ansi():
    if os.name == 'nt':
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            k.GetConsoleMode(h, ctypes.byref(mode))
            k.SetConsoleMode(h, mode.value | 0x0004)
        except Exception:
            pass


_enable_ansi()


def err(msg):
    print(f'{RED}[!] {msg}{RESET}')


def ok(msg):
    print(f'{GREEN}[!] {msg}{RESET}')


def info(msg):
    print(f'{BLUE}[i] {msg}{RESET}')


def usage():
    print(__doc__.strip().split('It creates', 1)[0])


def here():
    return os.path.dirname(os.path.abspath(__file__))


def local_version(base):
    """Version.txt next to install.py, or None."""
    p = os.path.join(base, 'Version.txt')
    if os.path.isfile(p):
        try:
            with open(p, encoding='utf-8') as f:
                v = f.read().strip()
            if v:
                return v
        except OSError:
            pass
    return None


def download_url(version, custom=None):
    """The zip URL to download (same file dcmdH_check.py / Startup.py use)."""
    if custom:
        return custom
    name = f'dcmdH v.e{version}.zip'
    return RAW_BASE + urllib.parse.quote(name)


def _temp_roots():
    """Writable temp locations to try, in order."""
    seen = set()
    for p in (tempfile.gettempdir(), os.getcwd(), here()):
        r = os.path.abspath(p)
        if r not in seen:
            seen.add(r)
            yield r


def fetch_payload(url):
    """Download + extract the dcmdH build zip. Returns the extracted root,
    or None on failure."""
    last_err = None
    for root in _temp_roots():
        # plain os.makedirs (not tempfile.mkdtemp) so the folder gets
        # normal permissions on every machine
        tmp = os.path.join(root, 'dcmdH_inst_' + uuid.uuid4().hex)
        try:
            os.makedirs(tmp, exist_ok=True)
        except OSError as e:
            last_err = e
            continue
        zpath = os.path.join(tmp, 'dcmdH.zip')
        print(f'[*] Downloading {url} ...')
        try:
            try:
                import certifi
                ctx = ssl.create_default_context(cafile=certifi.where())
            except Exception:
                ctx = ssl.create_default_context()
            req = urllib.request.Request(url,
                                         headers={'User-Agent': 'dcmdH-install'})
            with urllib.request.urlopen(req, timeout=120, context=ctx) as r, \
                    open(zpath, 'wb') as f:
                shutil.copyfileobj(r, f)
        except urllib.error.HTTPError as e:
            hint = ''
            if e.code == 404:
                hint = ' - that version is not uploaded to GitHub yet.'
            err(f'download failed: {e}{hint}')
            shutil.rmtree(tmp, ignore_errors=True)
            return None
        except OSError as e:
            last_err = e
            shutil.rmtree(tmp, ignore_errors=True)
            continue
        print('[*] Download finished. Extracting ...')
        try:
            with zipfile.ZipFile(zpath) as z:
                z.extractall(tmp)
        except (OSError, zipfile.BadZipFile) as e:
            last_err = e
            shutil.rmtree(tmp, ignore_errors=True)
            continue
        return tmp
    err(f'download failed: {last_err}')
    return None


def payload_root(base, dl_root):
    """Where the dcmdH files live. Returns (root, downloaded) or (None, ...)."""
    if os.path.isfile(os.path.join(base, 'dcmdH.py')) and \
            os.path.isfile(os.path.join(base, 'Startup.py')):
        return base, False
    if dl_root:
        for cand in (dl_root, os.path.join(dl_root, 'dcmdH')):
            if os.path.isfile(os.path.join(cand, 'dcmdH.py')) and \
                    os.path.isfile(os.path.join(cand, 'Startup.py')):
                return cand, True
    return None, False


def install_into(payload, target):
    """Copy the dcmdH payload from `payload` into `target`."""
    os.makedirs(target, exist_ok=True)
    print(f'Created folder [{target}].')
    n = 0
    for name in PAYLOAD_FILES:
        src = os.path.join(payload, name)
        if not os.path.isfile(src):
            continue
        dst = os.path.join(target, name)
        if os.path.normcase(os.path.abspath(src)) != \
                os.path.normcase(os.path.abspath(dst)):
            shutil.copy2(src, dst)
            n += 1
    if n:
        ok(f'copied {n} file(s) into the dcmdH folder.')

    build_src = os.path.join(payload, BUILD_DIR)
    build_dst = os.path.join(target, BUILD_DIR)
    if os.path.isdir(build_src):
        if os.path.normcase(os.path.abspath(build_src)) != \
                os.path.normcase(os.path.abspath(build_dst)):
            shutil.copytree(build_src, build_dst, dirs_exist_ok=True)
            print(f"Copied {BUILD_DIR} (compiled build) --> '{target}'.")
        else:
            print(f'{BUILD_DIR} is already inside the install folder.')
    else:
        info(f'no {BUILD_DIR} build found - dcmdH will run from source '
             f'(python dcmdH.py).')

    # Mark as installed: SkipCheck.txt makes dcmdH start normally instead
    # of opening its own installer (the same job it did for setup.py).
    for p in (os.path.join(target, 'SkipCheck.txt'),
              os.path.join(build_dst, 'SkipCheck.txt')):
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, 'w', encoding='utf-8') as f:
                f.write('')
        except OSError:
            pass
    print('Wrote SkipCheck.txt (dcmdH will start directly).')


def add_to_user_path(folder):
    """Add `folder` to the user PATH so `dcmdH` runs from anywhere."""
    if os.name != 'nt':
        return False
    f = folder.replace("'", "''")
    ps = (
        f"$t='{f}'; "
        "$p=[Environment]::GetEnvironmentVariable('Path','User'); "
        "if(-not $p){$p=''}; "
        "if (($p -split ';') -contains $t) "
        "{ Write-Host '[OK] Already in PATH: ' $t } "
        "else { [Environment]::SetEnvironmentVariable('Path', "
        "($p.TrimEnd(';') + ';' + $t), 'User'); "
        "Write-Host '[OK] Added to PATH: ' $t; "
        "Write-Host '[i] Open a NEW terminal, then type dcmdH.' }"
    )
    try:
        r = subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy',
                            'Bypass', '-Command', ps])
        return r.returncode == 0
    except OSError as e:
        err(f'cannot run powershell: {e}')
        return False


def main():
    # ---------------- arguments ----------------
    args = sys.argv[1:]
    path = None
    version = None
    url = None
    yes = False
    no_path = False
    i = 0
    while i < len(args):
        a = args[i]
        if a in ('-h', '--help', '/?'):
            usage()
            return 0
        if a in ('-y', '--yes'):
            yes = True
        elif a in ('--no', '--no-path'):
            no_path = True
        elif a == '--version':
            i += 1
            if i < len(args):
                version = args[i]
        elif a == '--url':
            i += 1
            if i < len(args):
                url = args[i]
        elif not a.startswith('-') and path is None:
            path = a
        i += 1

    base = here()
    V = version or local_version(base) or DEFAULT_VERSION
    print(f'Sunshine DCMD-H installer [e{V}]')

    # ---------------- where the program files come from ----------------
    payload, downloaded = payload_root(base, None)
    if payload is None:
        if not url:
            url = download_url(V)
        info(f'install.py is alone here - downloading dcmdH v.e{V} from GitHub ...')
        dl_root = fetch_payload(url)
        if not dl_root:
            return 1
        payload, downloaded = payload_root(base, dl_root)
        if payload is None:
            err('the download did not contain dcmdH.py / Startup.py.')
            shutil.rmtree(dl_root, ignore_errors=True)
            return 1
        ok('got the dcmdH files from the download.')
    else:
        ok('found the dcmdH files next to install.py.')

    # ---------------- where to install ----------------
    if path is None:
        try:
            path = input('Enter path to create folder [dcmdH] --> ').strip()
        except (EOFError, KeyboardInterrupt):
            path = ''
    if not path:
        err('No install path given, install aborted.')
        if downloaded:
            shutil.rmtree(payload, ignore_errors=True)
        return 1

    target = path
    if os.path.basename(path.rstrip('\\/')).lower() != APP_FOLDER:
        target = os.path.join(path, APP_FOLDER)

    try:
        install_into(payload, target)
    finally:
        if downloaded:
            shutil.rmtree(payload, ignore_errors=True)

    # Keep the copy next to install.py working too (like setup.py did).
    if not downloaded:
        p = os.path.join(base, 'SkipCheck.txt')
        if not os.path.isfile(p):
            try:
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('')
                print('Wrote SkipCheck.txt next to install.py.')
            except OSError:
                pass

    # ---------------- optional: add to PATH ----------------
    if no_path:
        info('skipped adding the folder to PATH.')
    else:
        do_path = yes
        if not yes:
            try:
                ans = input("Add this folder to PATH so you can run "
                            "'dcmdH' from anywhere? (y/n): ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                ans = ''
            do_path = ans in ('y', 'yes')
        if do_path:
            if add_to_user_path(target):
                ok('added to PATH.')
            else:
                info("couldn't add to PATH - run add_to_path.cmd inside the "
                     'folder later.')
        else:
            info('skipped PATH (run add_to_path.cmd inside the folder later).')

    print()
    ok('install complete.')
    print(f'Installed to: {target}')
    print(f'Run it with:  python "{os.path.join(target, "dcmdH.py")}"')
    print('  or open a new terminal and type: dcmdH  (if added to PATH)')
    print('  or double-click dcmdH.cmd inside the folder.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
