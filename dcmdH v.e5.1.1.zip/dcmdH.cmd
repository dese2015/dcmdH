@echo off
rem ============================================================
rem  dcmdH launcher
rem  Put this folder on PATH, then just type "dcmdH" anywhere.
rem  Runs the standalone self-check first when python is available.
rem ============================================================
cd /d "%~dp0"
python --version >nul 2>nul
if not errorlevel 1 (
    python "%~dp0dcmdH_check.py" %*
    exit /b %errorlevel%
)
if exist "%~dp0dist\dcmdH\dcmdH.exe" (
    "%~dp0dist\dcmdH\dcmdH.exe" %*
) else (
    echo [dcmdH] python not found and dist\dcmdH\dcmdH.exe not found.
    exit /b 1
)
