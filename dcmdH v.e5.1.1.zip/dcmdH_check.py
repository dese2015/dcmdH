# dcmdH_check.py - standalone self-check + launcher for dcmdH
#
#   python dcmdH_check.py            auto-detect: exe build if fresh, else source
#   python dcmdH_check.py exe        check the dist exe build, then run dcmdH.exe
#   python dcmdH_check.py py         check the source files, then run dcmdH.py
#
#   any other arguments are forwarded to dcmdH after the check passes.
#
#   all pass  -> runs dcmdH
#   problems  -> type 'download lost' to download the missing files,
#                or 'quit' to exit without running dcmdH.
#
# Download source: set UPDATE_URL in Startup.py (zip of the dcmdH build),
# or override UPDATE_URL below.

import os, sys, shutil, subprocess, re, zipfile, ssl, tempfile, datetime

try:
    import Startup
    UPDATE_URL = Startup.UPDATE_URL
except Exception:
    UPDATE_URL = None
# Env var override (also handy for testing):  set DCMDH_UPDATE_URL=...
UPDATE_URL = os.environ.get('DCMDH_UPDATE_URL') or UPDATE_URL
# UPDATE_URL = 'https://example.com/dcmdH.zip'   # override here if you prefer

# ---------------- colors ----------------
RED = '\033[91m'
GREEN = '\033[92m'
BLUE = '\033[94m'
RESET = '\033[0m'


def _enable_ansi():
    if os.name == 'nt':
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            k.GetConsoleMode(h, ctypes.byref(mode))
            k.SetConsoleMode(h, mode.value | 0x0004)
        except Exception:
            pass


_enable_ansi()


def err(msg):
    print(f'{RED}[!] {msg}{RESET}')


def ok(msg):
    print(f'{GREEN}[!] {msg}{RESET}')


def info(msg):
    print(f'{BLUE}[i] {msg}{RESET}')


def app_home():
    """Folder that holds this checker (the dcmdH folder)."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def size_str(full):
    if os.path.isfile(full):
        size = os.path.getsize(full)
        return (f"{size} Bt" if size < 1024 else
                f"{size/1024:.2f} KB" if size < 1024**2 else
                f"{size/1024**2:.2f} MB" if size < 1024**3 else
                f"{size/1024**3:.2f} GB")
    return "folder" if os.path.isdir(full) else "unknown"


def _mem_status():
    """Return (total, available) physical memory in bytes, or (None, None)."""
    try:
        import ctypes
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ('dwLength', ctypes.c_ulong),
                ('dwMemoryLoad', ctypes.c_ulong),
                ('ullTotalPhys', ctypes.c_ulonglong),
                ('ullAvailPhys', ctypes.c_ulonglong),
                ('ullTotalPageFile', ctypes.c_ulonglong),
                ('ullAvailPageFile', ctypes.c_ulonglong),
                ('ullTotalVirtual', ctypes.c_ulonglong),
                ('ullAvailVirtual', ctypes.c_ulonglong),
                ('ullAvailExtendedVirtual', ctypes.c_ulonglong),
            ]
        s = MEMORYSTATUSEX()
        s.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s)):
            return int(s.ullTotalPhys), int(s.ullAvailPhys)
    except Exception:
        pass
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.total), int(vm.available)
    except Exception:
        pass
    try:
        with open('/proc/meminfo', encoding='utf-8') as f:
            d = {}
            for ln in f:
                if ':' in ln:
                    k, v = ln.split(':', 1)
                    d[k] = int(v.strip().split()[0]) * 1024
        if 'MemTotal' in d:
            return d['MemTotal'], d.get('MemAvailable', d.get('MemFree', 0))
    except Exception:
        pass
    return None, None


def _mem_str(n):
    if n is None:
        return 'unknown'
    if n < 1024:
        return f'{n} Bt'
    if n < 1024**2:
        return f'{n/1024:.2f} KB'
    if n < 1024**3:
        return f'{n/1024**2:.2f} MB'
    return f'{n/1024**3:.2f} GB'


def build_checks(mode, base):
    """Build the integrity check list for a mode. Returns (checks, exe_path)."""
    checks = []
    exe_path = None
    if mode == 'exe':
        exe_path = os.path.join(base, 'dist', 'dcmdH', 'dcmdH.exe')
        checks = [
            ('dist/dcmdH/dcmdH.exe', exe_path, 'file'),
            ('dist/dcmdH/_internal',
             os.path.join(base, 'dist', 'dcmdH', '_internal'), 'dir'),
            ('dist/dcmdH/_internal/base_library.zip',
             os.path.join(base, 'dist', 'dcmdH', '_internal', 'base_library.zip'), 'file'),
            ('dist/dcmdH/_internal/python runtime dll',
             os.path.join(base, 'dist', 'dcmdH', '_internal'), 'pydll'),
            ('dist/dcmdH/Version.txt',
             os.path.join(base, 'dist', 'dcmdH', 'Version.txt'), 'file'),
            ('dcmdH icon', exe_path, 'embedded'),
        ]
    else:
        checks = [
            ('dcmdH.py', os.path.join(base, 'dcmdH.py'), 'file'),
            ('Startup.py', os.path.join(base, 'Startup.py'), 'file'),
            ('Version.txt', os.path.join(base, 'Version.txt'), 'file'),
            ('dcmdH icon.ico', os.path.join(base, 'dcmdH icon.ico'), 'icon'),
        ]
    return checks, exe_path


def run_check(mode, base):
    """Run the integrity checks. Returns (problems, exe_path).
    Each problem is (label, path, kind) with kind in file/dir."""
    print('=' * 92)
    info(f'dcmdH self-check ({mode} mode)')
    checks, exe_path = build_checks(mode, base)
    problems = []
    for label, path, kind in checks:
        if kind == 'embedded':
            print(f'  [OK] {label} (embedded in dcmdH.exe)')
            continue
        if kind == 'icon':
            if os.path.isfile(path) and os.path.getsize(path) > 0:
                print(f'  [OK] {label}  {size_str(path)}')
                continue
            restored = False
            if 'Startup' in sys.modules and getattr(Startup, 'ICON_B64', None):
                try:
                    import base64
                    with open(path, 'wb') as f:
                        f.write(base64.b64decode(Startup.ICON_B64))
                    restored = True
                    print(f'  [OK] {label} (restored from embedded data)')
                except OSError:
                    pass
            if not restored:
                problems.append((label, path, 'file'))
                err(f'  missing: {label}')
            continue
        if kind == 'pydll':
            try:
                hits = sorted(n for n in os.listdir(path)
                              if re.match(r'python\d+\.dll$', n))
            except OSError:
                hits = []
            if hits:
                p = os.path.join(path, hits[0])
                print(f'  [OK] {label}: {hits[0]}  {size_str(p)}')
            else:
                # the whole _internal folder is suspect -> restore it whole
                problems.append(('dist/dcmdH/_internal', path, 'dir'))
                err(f'  missing {label} in {path}')
            continue
        if kind == 'dir':
            if os.path.isdir(path):
                print(f'  [OK] {label}  (folder)')
            else:
                problems.append((label, path, 'dir'))
                err(f'  missing {label}')
            continue
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            print(f'  [OK] {label}  {size_str(path)}')
        else:
            problems.append((label, path, 'file'))
            err(f'  missing or empty: {label}')
    return problems, exe_path


def report_version(mode, base, exe_path):
    if mode == 'exe':
        vpath = os.path.join(base, 'dist', 'dcmdH', 'Version.txt')
    else:
        vpath = os.path.join(base, 'Version.txt')
    V = 'unknown'
    if os.path.isfile(vpath):
        try:
            with open(vpath, encoding='utf-8') as f:
                V = f.read().strip() or 'unknown'
        except OSError:
            pass
    print()
    info('version:')
    print(f'  source version = {V}')
    if mode == 'exe' and exe_path and os.path.isfile(exe_path):
        try:
            mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(exe_path)).strftime('%Y-%m-%d %H:%M')
        except OSError:
            mtime = 'unknown'
        print(f'  dcmdH exe version = e{V}')
        print(f'  exe path = {exe_path}')
        print(f'  exe size = {size_str(exe_path)}, built {mtime}')
    else:
        print('  There is no dcmdH exe version.')
        print('  (build one with: pyinstaller dcmdH.spec)')


def report_memory():
    total, avail = _mem_status()
    print()
    info('memory:')
    print(f'  total physical   = {_mem_str(total)}')
    print(f'  available memory = {_mem_str(avail)}')
    if total and avail is not None:
        print(f'  used             = {100.0 * (total - avail) / total:.1f}%')


def _find_in_tree(root_dir, expected_rel):
    """Find a file/folder in the extracted zip, preferring the right layout."""
    best = None
    best_score = -1
    exp = os.path.normpath(expected_rel).lower()
    for r, dirs, files in os.walk(root_dir):
        for name in dirs + files:
            full = os.path.join(r, name)
            rel = os.path.normpath(os.path.relpath(full, root_dir)).lower()
            if rel == exp:
                score = 3
            elif rel.endswith(exp):
                score = 2
            elif name.lower() == os.path.basename(exp):
                score = 1
            else:
                score = 0
            if score >= 1 and score > best_score:
                best, best_score = full, score
    return best


def download_lost(problems, mode):
    """Download the dcmdH build zip and restore every missing file/folder.
    Returns True when all problems were restored."""
    if not UPDATE_URL:
        err('no download source configured (set UPDATE_URL in Startup.py)')
        return False
    tmp = tempfile.mkdtemp(prefix='dcmdH_lost_')
    zpath = os.path.join(tmp, 'dcmdH.zip')
    try:
        import urllib.request
        import urllib.error
        print(f'[*] Downloading {UPDATE_URL} ...')
        try:
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            ctx = ssl.create_default_context()
        req = urllib.request.Request(UPDATE_URL, headers={'User-Agent': 'dcmdH-check'})
        with urllib.request.urlopen(req, timeout=120, context=ctx) as r, open(zpath, 'wb') as f:
            shutil.copyfileobj(r, f)
        print('[*] Download finished. Extracting ...')
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tmp)
    except urllib.error.HTTPError as e:
        hint = ''
        if e.code == 404:
            hint = (' - the zip is not uploaded there yet. Upload dcmdH.zip '
                    'to your GitHub repo first.')
        err(f'download failed: {e}{hint}')
        shutil.rmtree(tmp, ignore_errors=True)
        return False
    except Exception as e:
        err(f'download failed: {e}')
        shutil.rmtree(tmp, ignore_errors=True)
        return False

    fixed = []
    still = []
    for label, path, kind in problems:
        found = _find_in_tree(tmp, label)
        if not found:
            err(f'  not found in the download: {label}')
            still.append(label)
            continue
        try:
            if os.path.isdir(found):
                shutil.copytree(found, path, dirs_exist_ok=True)
            else:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                shutil.copy2(found, path)
            fixed.append(label)
            ok(f'  restored {label}')
        except OSError as e:
            err(f'  cannot restore {label}: {e}')
            still.append(label)
    shutil.rmtree(tmp, ignore_errors=True)
    if fixed:
        ok(f'restored {len(fixed)} item(s).')
    if still:
        err(f'still missing after download: {", ".join(still)}')
    return not still


def launch(mode, args):
    base = app_home()
    sys.stdout.flush()  # keep check output ordered when stdout is piped
    if mode == 'exe':
        exe = os.path.join(base, 'dist', 'dcmdH', 'dcmdH.exe')
        subprocess.run([exe] + args)
    else:
        script = os.path.join(base, 'dcmdH.py')
        subprocess.run([sys.executable, script] + args)


def main():
    base = app_home()
    args = sys.argv[1:]
    mode = None
    if args and args[0].lower() in ('exe', 'py', 'source'):
        mode = args.pop(0).lower()
        mode = 'py' if mode == 'source' else mode

    exe_path0 = os.path.join(base, 'dist', 'dcmdH', 'dcmdH.exe')
    src_path = os.path.join(base, 'dcmdH.py')
    if mode is None:
        if os.path.isfile(exe_path0):
            if (os.path.isfile(src_path) and
                    os.path.getmtime(src_path) > os.path.getmtime(exe_path0)):
                mode = 'py'
                info('dcmdH.py is newer than the exe build -> checking source mode')
            else:
                mode = 'exe'
        else:
            mode = 'py'

    print()
    problems, exe_path = run_check(mode, base)
    report_version(mode, base, exe_path)
    report_memory()

    print()
    if not problems:
        ok('all pass. Starting dcmdH ...')
        print()
        launch(mode, args)
        return

    err(f'problems found ({len(problems)}):')
    for label, path, kind in problems:
        print(f'   - {label}')
    print()
    while True:
        try:
            ans = input("Type 'download lost' to download the missing files, "
                        "or 'quit' to exit: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            print('Bye.')
            return
        if ans.lower() == 'quit':
            print('Bye.')
            return
        if ans.lower() == 'download lost':
            if download_lost(problems, mode):
                problems, exe_path = run_check(mode, base)
                if not problems:
                    report_version(mode, base, exe_path)
                    report_memory()
                    print()
                    ok('all pass now. Starting dcmdH ...')
                    print()
                    launch(mode, args)
                    return
                print()
                err(f'still {len(problems)} problem(s).')
        else:
            info("type 'download lost' or 'quit'")


if __name__ == '__main__':
    main()
