import os, shutil, subprocess, sys, time, string, re, datetime
import unicodedata
import Startup


# ---------------- colors & tags ----------------
RED = '\033[91m'
GREEN = '\033[92m'
BLUE = '\033[94m'
RESET = '\033[0m'


def _enable_ansi():
    if os.name == 'nt':
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            k.GetConsoleMode(h, ctypes.byref(mode))
            k.SetConsoleMode(h, mode.value | 0x0004)
        except Exception:
            pass


_enable_ansi()


def err(msg):
    print(f'{RED}[!] {msg}{RESET}')

def red(msg):
    print(f'{RED} {msg}{RESET}')

def ok(msg):
    print(f'{GREEN}[!] {msg}{RESET}')

def info(msg):
    print(f'{BLUE}[i] {msg}{RESET}')

def mode(msg):
    print(f'{BLUE}[Run] {msg}{RESET}')

def start(msg):
    print(f'{GREEN}[Start] {msg}{RESET}')


line = 0
repcmd = 1
shut = False
if os.path.isfile('Version.txt'):
    with open('Version.txt', encoding="utf-8") as f:
        V = f.read().strip()
else:
    V = '5.1.0'

def ask(prompt=''):
    global line
    line += 1
    return input(f'{line} {prompt_path()}{prompt} ')

def prompt_path():
    """Current folder shown in the prompt (with a trailing separator)."""
    return cur if cur.endswith(('\\', '/')) else cur + os.sep

def to_abs(path):
    """Turn a user-typed path into a real absolute path anywhere on the machine."""
    p = path.strip()
    # Absolute Windows path with a drive letter: C:\..., D:\... or just "C:" (drive root).
    if len(p) >= 2 and p[1] == ':' and p[0].isalpha():
        return p + '\\' if len(p) == 2 else os.path.normpath(p)
    # UNC / network share.
    if p.startswith('\\\\') or p.startswith('//'):
        return os.path.normpath(p)
    # Rooted on the current drive: \foo or /foo.
    if p.startswith('\\') or p.startswith('/'):
        drive = os.path.splitdrive(cur)[0] or os.path.splitdrive(os.getcwd())[0]
        return os.path.normpath(os.path.join(drive + os.sep, p.lstrip('\\/')))
    # Relative to the current folder.
    return os.path.normpath(os.path.join(cur, p))

def resolve(path):
    return to_abs(path)

def join_path(path):
    return to_abs(path)

Startup.run_startup()

# dcmdH starts in the folder it was run from (no EasyPathData.txt needed),
# and you can cd anywhere or type any absolute path.
cur = os.getcwd()

def write():
    global repcmd
    for _ in range(repcmd):
        filename = ask('write *filename*')
        typ = ask(f'write {filename} *type*')
        wpath = resolve(ask(f'write {filename} in *path*'))
        if typ == 'folder':
            full = os.path.join(wpath, filename)
            if not os.path.exists(full):
                os.makedirs(full, exist_ok=True)
                ok(f'made {filename}.')
            else:
                info(f'folder {filename} already exists.')
            continue
        filename += typ
        obj = ask(f'write {filename} *WriteObj*')
        lines = []
        if obj == '~~':
            while (m := ask('WriteObj')) != 'endEl~~':
                lines.append(m)
        else:
            lines.append(obj)
        os.makedirs(wpath, exist_ok=True)
        with open(os.path.join(wpath, filename), 'w', encoding='utf-8', newline='\n') as f:
            f.write('\n'.join(lines))
        ok(f'wrote {filename} to {wpath}.')
    repcmd = 1

def read():
    global repcmd
    for _ in range(repcmd):
        rpath = resolve(ask('read'))
        if os.path.exists(rpath):
            with open(rpath, encoding='utf-8') as f:
                ok(f'read {rpath}.')
                print(f.read())
                print('^^^^^^')
        else:
            err(f'read path {rpath} does not exist.')
    repcmd = 1

def delete():
    global repcmd
    for _ in range(repcmd):
        dpath = resolve(ask('delete'))
        if os.path.isdir(dpath):
            if ask(f'delete folder {dpath}? (y/n)').strip().lower() == 'y':
                shutil.rmtree(dpath)
                ok(f'deleted folder {dpath}.')
            else:
                info('cancelled.')
        elif os.path.exists(dpath):
            os.remove(dpath)
            ok(f'deleted {dpath}.')
        else:
            err(f'delete path {dpath} does not exist.')
    repcmd = 1

def copy():
    global repcmd
    for _ in range(repcmd):
        src = resolve(ask('copy '))
        dst = resolve(ask('copy to '))
        if not os.path.exists(src):
            err(f'copy source {src} does not exist.')
            continue
        if os.path.isdir(src):
            target = os.path.join(dst, os.path.basename(src))
            if os.path.exists(target):
                info(f'copy: destination {target} already exists.')
                continue
            os.makedirs(dst, exist_ok=True)
            shutil.copytree(src, target)
            ok(f'copied folder {src} -> {target}.')
        else:
            os.makedirs(dst, exist_ok=True)
            shutil.copy(src, dst)
            ok(f'copied file {src} -> {dst}.')
    repcmd = 1

def rep():
    global repcmd
    cmd = ask('rep command')
    repcmd = int(ask(f'{cmd} do *int* times'))
    {'write': write, 'read': read, 'del': delete, 'copy': copy}.get(cmd, lambda: None)()

def disp_width(s):
    """Display width: Chinese/fullwidth chars take 2 columns in a terminal."""
    return sum(2 if unicodedata.east_asian_width(ch) in ('W', 'F') else 1 for ch in s)

def size_str(full):
    if os.path.isfile(full):
        size = os.path.getsize(full)
        return (f"{size} Bt" if size < 1024 else
                f"{size/1024:.2f} KB" if size < 1024**2 else
                f"{size/1024**2:.2f} MB" if size < 1024**3 else
                f"{size/1024**3:.2f} GB")
    return "folder" if os.path.isdir(full) else "unknown"

def print_dir_table(dpath, entries):
    print('=' * 92)
    for name in entries:
        full = os.path.join(dpath, name)
        s = size_str(full)
        pad = max(0, 90 - disp_width(name + s) - 2)
        print(f"|{name} {'-' * pad} {s}|")
    print('=' * 92)

def dir():
    raw = ask('dir')
    dpath = to_abs(raw) if raw.strip() else cur
    info(f'Obj Path >>> {dpath}')
    if not os.path.isdir(dpath):
        err('Path not found!')
        print('=' * 32)
        return
    try:
        entries = os.listdir(dpath)
    except PermissionError:
        err('Access denied!')
        return
    print_dir_table(dpath, entries)

def dir_h():
    info('dir whole computer done.')
    for letter in string.ascii_uppercase:
        drive = f'{letter}:\\'
        if not os.path.exists(drive):
            continue
        print(f'\n===== Drive {drive} =====')
        try:
            entries = os.listdir(drive)
        except PermissionError:
            print('[Access denied]')
            continue
        if not entries:
            print('(empty)')
            continue
        print_dir_table(drive, entries)
    print()

def cd():
    global cur
    target = to_abs(ask('cd'))
    if os.path.isdir(target):
        cur = target
        info(f'cd to {cur}.')
    else:
        err(f'cd: {target} is not a folder or does not exist.')

def dirncur():
    global cur
    dpath = to_abs(cur) if cur.strip() else cur
    info(f'Obj Path >>> {dpath}')
    if not os.path.isdir(dpath):
        err('Path not found!')
        print('=' * 32)
        return
    try:
        entries = os.listdir(dpath)
    except PermissionError:
        err('Access denied!')
        return
    print_dir_table(dpath, entries)

def run():
    rpath = join_path(ask('run *path*'))
    if os.path.isfile(rpath) and rpath.endswith(".py"):
        subprocess.run(["python", rpath])
    else:
        err('Invalid Python file path!')
    info(f"end run program '{rpath}'.")

def shutdown():
    global shut
    t = ask('end')
    if t == '/n':
        shut = True
    elif t == '/t':
        wait = int(ask('end /t'))
        print('*************************************')
        info('caution!')
        info(f'this programme will end in {wait} secs')
        print('*************************************')
        time.sleep(wait)
        shut = True
    elif t == '/q':
        shut = False
    else:
        print('----------------------------------------------')
        err('Type Error')
        print('you may try:')
        print('/n shutdown right now')
        print('/t shutdown after a controlable amount of time')
        print('/q exit shutdown command')
        print('----------------------------------------------')

def shutdownn():
    global shut
    shut = True

PY_NS = {'os': os, 'shutil': shutil, 'subprocess': subprocess, 'time': time, 'string': string}

def collect_lines(label):
    lines = []
    while True:
        l = ask(label)
        if l.strip() == 'endP~~':
            break
        lines.append(l)
    return lines

# ---------------- progP: Python ----------------
def progP():
    mode('progP: type Python code, end with endP~~')
    lines = collect_lines('py')
    code = '\n'.join(lines)
    start('progP start')
    try:
        exec(code, PY_NS)
    except Exception as e:
        err(f'progP error: {type(e).__name__}: {e}')
    mode('progP done')
# ---------------- progD: custom data codes ----------------
DVARS = {}

# progD user functions: name -> {'params': [...], 'body': [...], 'export': bool}
DFUNCS = {}


def call_dfunc(name, args_s):
    """Run a user function defined with !name(var): in progD.
    Parameter assignments stay in DVARS after the call (macro style),
    so functions like !load(v,p): v = load(p) keep their result."""
    f = DFUNCS[name]
    parts = [p.strip() for p in args_s.split(',') if p.strip()]
    if len(parts) != len(f['params']):
        err(f'!{name} needs {len(f["params"])} argument(s), got {len(parts)}')
        return
    for p, a in zip(f['params'], parts):
        ok, val = eval_data_expr(a)
        DVARS[p] = val if ok else to_number(a)
    start(f'!{name} start')
    for stmt in f['body']:
        exec_data_statement(stmt)
    mode(f'!{name} done')


FUNCS_FILE = 'SaveFuncs.txt'


def _parse_def(lines, idx):
    """Parse !name(params): + indented body from lines at idx.
    Returns (name, params, body, new_idx) or (None, None, None, idx + 1)."""
    line = lines[idx].strip()
    m = re.match(r'!(\w+)\s*\((.*)\)\s*:\s*$', line)
    if not m:
        return None, None, None, idx + 1
    name = m.group(1)
    params = [p.strip() for p in m.group(2).split(',') if p.strip()]
    idx += 1
    body = []
    while idx < len(lines) and lines[idx].startswith(('\t', ' ')):
        b = lines[idx].strip()
        low = b.lower()
        if low == 'do':
            b = ''
        elif low.startswith('do '):
            b = b[3:].strip()
        elif low.startswith('do\t'):
            b = b[3:].strip()
        if b:
            body.append(b)
        idx += 1
    return name, params, body, idx


def save_funcs():
    """Persist all defined functions to FUNCS_FILE (progD syntax)."""
    try:
        with open(FUNCS_FILE, 'w', encoding='utf-8') as f:
            for name, d in DFUNCS.items():
                f.write(f'!{name}({", ".join(d["params"])}):\n')
                for stmt in d['body']:
                    f.write(f'    {stmt}\n')
                if d['export']:
                    f.write('@\n')
                f.write('\n')
    except OSError as e:
        err(f'save functions failed: {e}')


def load_funcs():
    """Load persisted functions from FUNCS_FILE at startup."""
    if not os.path.isfile(FUNCS_FILE):
        return
    try:
        with open(FUNCS_FILE, encoding='utf-8') as f:
            lines = f.read().splitlines()
    except OSError as e:
        err(f'load functions failed: {e}')
        return
    loaded = []
    idx = 0
    while idx < len(lines):
        line = lines[idx].strip()
        if not line:
            idx += 1
            continue
        if line.startswith('!') and line.endswith(':') and '(' in line:
            name, params, body, idx = _parse_def(lines, idx)
            if name is None:
                idx += 1
                continue
            exp = False
            if idx < len(lines) and lines[idx].strip() == '@':
                exp = True
                idx += 1
            DFUNCS[name] = {'params': params, 'body': body, 'export': exp}
            loaded.append(name)
        else:
            idx += 1
    if loaded:
        info(f'loaded functions: {", ".join(loaded)}')


def eval_data_expr(s):
    g = dict(DVARS)
    g['__builtins__'] = {}
    try:
        return True, eval(s, g)
    except Exception as e:
        return False, e


def data_arg(s):
    s = s.strip()
    ok, val = eval_data_expr(s)
    if ok and isinstance(val, (int, float)):
        return val
    try:
        return float(s)
    except Exception:
        return None


def to_number(s):
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        return s


def data_assign(line):
    lm = None
    quoted = False
    for pat in (r"(\w+)\s*=\s*load\(\s*'([^']*)'\s*\)\s*$",
                r'(\w+)\s*=\s*load\(\s*"([^"]*)"\s*\)\s*$'):
        lm = re.match(pat, line)
        if lm:
            quoted = True
            break
    if not lm:
        lm = re.match(r"(\w+)\s*=\s*load\(\s*(.+?)\s*\)\s*$", line)
    if lm:
        name, path = lm.group(1), lm.group(2).strip()
        if not quoted:
            # Unquoted argument can be a variable / expression, e.g. v = load(p)
            ok, val = eval_data_expr(path)
            if ok and isinstance(val, str):
                path = val
        try:
            with open(path, encoding='utf-8') as f:
                DVARS[name] = to_number(f.read().strip())
        except Exception as e:
            err(f'load error {path!r}: {e}')
            DVARS[name] = ''
        info(f'{name} = {DVARS[name]!r}')
        return
    g = dict(DVARS)
    g['__builtins__'] = {}
    try:
        exec(line, g)
    except Exception as e:
        err(f'assign error {line!r}: {e}')
        return
    for k, v in g.items():
        if k == '__builtins__':
            continue
        DVARS[k] = v
    nm = re.match(r'(\w+)\s*[+\-*/%]*=', line)
    if nm:
        info(f'{nm.group(1)} = {DVARS.get(nm.group(1))!r}')

MAX_CHART_VALUES = 12

MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')

def mk_bc(line):
    m = re.match(r"mk\s+BC\s+with\s*\((.*)\)\s*$", line, re.IGNORECASE)
    if not m:
        err('syntax: mk BC with (a, b, ...)')
        return
    parts = [p.strip() for p in m.group(1).split(',') if p.strip()]
    if len(parts) < 2:
        err('mk BC needs at least 2 values')
        return
    if len(parts) > MAX_CHART_VALUES:
        err(f'mk BC max {MAX_CHART_VALUES} values, got {len(parts)}')
        return
    vals = [data_arg(p) for p in parts]
    if any(v is None for v in vals):
        err('mk BC needs numbers or variables')
        return
    info('Bar Chart:')
    mval = max(max(abs(v) for v in vals), 1)
    scale = 50 / mval
    val_strs = [f'{v:g}' for v in vals]
    lw = max(len(x) for x in parts)
    vw = max(len(x) for x in val_strs)
    for label, v, vs in zip(parts, vals, val_strs):
        bar = '█' * max(1, int(round(abs(v) * scale)))
        print(f'  {label:>{lw}} ({vs:>{vw}}): {bar}')

def _to_minutes(t):
    """'10:30' -> 630, or a plain number as minutes; None if unparseable."""
    t = t.strip()
    if ':' in t:
        try:
            hh, mm = t.split(':', 1)
            return int(hh) * 60 + int(mm)
        except ValueError:
            return None
    try:
        return float(t)
    except ValueError:
        return None


def mk_lc(line):
    # optional t(title) at the end
    title = None
    mt = re.search(r"\s+t\s*\((.*)\)\s*$", line, re.IGNORECASE)
    if mt:
        title = mt.group(1).strip()
        line = line[:mt.start()].rstrip()
    # optional from (time,time) or from [(day,month),(day,month)] at the end
    from_part = None
    mf = re.search(r"\s+from\s*(\[.*?\]|\(.*?\))\s*$", line, re.IGNORECASE)
    if mf:
        from_part = mf.group(1).strip()
        line = line[:mf.start()].rstrip()
    m = re.match(r"mk\s+LC\s+with\s*\((.*)\)\s*$", line, re.IGNORECASE)
    if not m:
        err('syntax: mk LC with (a, b, ...) from (10:00, 12:30) t(title)')
        return
    parts = [p.strip() for p in m.group(1).split(',') if p.strip()]
    if len(parts) < 2:
        err('mk LC needs at least 2 values')
        return
    if len(parts) > MAX_CHART_VALUES:
        err(f'mk LC max {MAX_CHART_VALUES} values, got {len(parts)}')
        return
    vals = [data_arg(p) for p in parts]
    if any(v is None for v in vals):
        err('mk LC needs numbers or variables')
        return
    t_start = t_end = None
    d_start = d_end = None
    if from_part is not None:
        if from_part.startswith('['):
            pairs = re.findall(r"\(\s*([^,)]+)\s*,\s*([^)]+)\s*\)", from_part)
            if len(pairs) != 2:
                err('mk LC from [(day,month),(day,month)] needs two date pairs, e.g. [(1,2),(2,2)] (no year needed)')
                return
            try:
                year = datetime.date.today().year
                def _mkdate(day, mon, y):
                    return datetime.datetime(y, int(round(float(mon))), int(round(float(day))))
                d_start = _mkdate(data_arg(pairs[0][0]), data_arg(pairs[0][1]), year)
                d_end = _mkdate(data_arg(pairs[1][0]), data_arg(pairs[1][1]), year)
                if None in (d_start, d_end):
                    raise ValueError('bad date')
                if d_end < d_start:
                    d_end = d_end.replace(year=year + 1)
            except Exception:
                err(f'mk LC from bad dates: {from_part!r} (use like [(1,2),(2,2)] = 1 Feb to 2 Feb; day,month only)')
                return
        else:
            tr = [x.strip() for x in from_part.strip('()').split(',') if x.strip()]
            if len(tr) != 2:
                err('mk LC from needs (start, end), e.g. from (10:00, 12:30)')
                return
            t_start, t_end = _to_minutes(tr[0]), _to_minutes(tr[1])
            if t_start is None or t_end is None:
                err(f'mk LC from bad times: {tr[0]!r}, {tr[1]!r} (use like 10:00, 12:30)')
                return
    info('Line Chart:')
    height = 26
    width = 88
    if title:
        print(' ' * 8 + title.center(width).rstrip())
    vmax = max(vals)
    vmin = min(vals)
    if vmax == vmin:
        vmax += 1
        vmin -= 1
    n = len(vals)
    xs = [round(i * (width - 1) / (n - 1)) for i in range(n)]
    ys = [round((vmax - v) / (vmax - vmin) * height) for v in vals]
    grid = [[' '] * width for _ in range(height + 1)]
    for i in range(n - 1):
        steps = max(abs(xs[i + 1] - xs[i]), abs(ys[i + 1] - ys[i]), 1)
        for s in range(steps + 1):
            x = round(xs[i] + (xs[i + 1] - xs[i]) * s / steps)
            y = round(ys[i] + (ys[i + 1] - ys[i]) * s / steps)
            if 0 <= y <= height and 0 <= x < width:
                grid[y][x] = '*'
    for row in range(height + 1):
        v = vmax - (vmax - vmin) * row / height
        print(f'{v:6.1f} |{"".join(grid[row])}')
    print('       ' + '-' * width)
    if t_start is not None or d_start is not None:
        # time / date axis labels under the x axis
        axis = [' '] * width
        for i in range(n):
            if d_start is not None:
                off = (d_end - d_start).total_seconds() * i / (n - 1)
                dt = d_start + datetime.timedelta(seconds=off)
                s = f'{dt.day}{MONTHS[dt.month - 1]}'
            else:
                tm = t_start + (t_end - t_start) * i / (n - 1)
                s = f'{int(tm // 60):02d}:{int(tm % 60):02d}'
            pos = max(0, min(width - len(s), xs[i]))
            for j, ch in enumerate(s):
                if pos + j < width:
                    axis[pos + j] = ch
        print('       ' + ''.join(axis).rstrip())
    legend = '   '.join(f'{p}={v:g}' for p, v in zip(parts, vals))
    print('      ' + legend)

def data_while(cond, body):
    i = 0
    while True:
        g = dict(DVARS)
        g['__builtins__'] = {}
        g['i'] = i
        try:
            r = eval(cond, g)
        except Exception as e:
            err(f'bad condition {cond!r}: {e}')
            return
        if not bool(r):
            break
        for cmd in body:
            if cmd == 'break':
                mode('break')
                return
            exec_data_statement(cmd)
        i += 1
        if i >= 1000:
            err(f'stopped after {i} loops: condition {cond!r} stayed True. Use break or change the variable.')
            return

def exec_data_statement(line):
    line = line.strip()
    if not line or line == 'break':
        return
    if re.match(r"mk\s+BC", line, re.IGNORECASE):
        mk_bc(line)
    elif re.match(r"mk\s+LC", line, re.IGNORECASE):
        mk_lc(line)
    elif re.match(r'(\w+)\s*[+\-*/%]*=', line):
        data_assign(line)
    else:
        cm = re.match(r'(\w+)\s*\((.*)\)\s*$', line)
        if cm and cm.group(1) in DFUNCS:
            call_dfunc(cm.group(1), cm.group(2))
        else:
            # Bare expression: comparisons and and/or/not logic, e.g.
            #   x > 1 and y < 5      ->  True / False
            #   not flag             ->  True / False
            ok, val = eval_data_expr(line)
            if ok:
                info(f'{line} = {val!r}')
            else:
                err(f'bad expression {line!r}: {val}')

def dezwu():
    print('hi! Thank you for using dcmdH by Desmond first,')
    print('how did you know this secret command?')
    print('did you find this in a bunch of codes?')
    print('or did you just type it randomly?')
    print('anyways, thank you for using dcmdH XD!')
    print('hope you have a great day.')
    print('                                      ---Dez XD')

def progD():
    mode('progD: type codes, end with endP~~')
    lines = collect_lines('D')
    start('progD start')
    idx = 0
    block_defs = []
    while idx < len(lines):
        line = lines[idx].strip()
        if not line:
            idx += 1
            continue
        if line == '@':
            if block_defs:
                for name in block_defs:
                    if name in DFUNCS:
                        DFUNCS[name]['export'] = True
                ok(f'exported to dcmdH: {", ".join(block_defs)}')
            else:
                info('@ needs a !function before it')
            idx += 1
            continue
        if line.startswith('while(') and line.endswith(':'):
            cond = line[line.index('(') + 1:line.rindex(')')].strip()
            idx += 1
            body = []
            while idx < len(lines) and lines[idx].startswith(('\t', ' ')):
                b = lines[idx].strip()
                low = b.lower()
                if low == 'do':
                    b = ''
                elif low.startswith('do '):
                    b = b[3:].strip()
                elif low.startswith('do\t'):
                    b = b[3:].strip()
                if b:
                    body.append(b)
                idx += 1
            data_while(cond, body)
        elif line.startswith('!') and line.endswith(':') and '(' in line:
            name, params, body, idx = _parse_def(lines, idx)
            if name is None:
                err(f'bad def syntax {line!r} (use: !name(var1, var2):)')
                continue
            prev = DFUNCS.get(name)
            DFUNCS[name] = {'params': params, 'body': body,
                            'export': prev['export'] if prev else False}
            block_defs.append(name)
            ok(f'defined !{name}({", ".join(params)})')
        elif line.startswith('!del '):
            name = line[5:].strip()
            if name in DFUNCS:
                del DFUNCS[name]
                ok(f'deleted function !{name}.')
            else:
                err(f'function {name!r} not available.')
                err(f'function {name!r} does not exist.')
            idx += 1
        else:
            exec_data_statement(line)
            idx += 1
    save_funcs()
    mode('progD done')


def delfunc():
    """Delete a user function defined with !name(var): (and save)."""
    name = ask('delfunc *name*').strip()
    if name in DFUNCS:
        del DFUNCS[name]
        save_funcs()
        ok(f'deleted function !{name}.')
    else:
        err(f'function {name!r} not available.')
        err(f'function {name!r} does not exist.')


def list_funcs():
    """List all user functions (dcmdH = exported, progD = internal)."""
    if not DFUNCS:
        info('no functions defined.')
        return
    info('defined functions:')
    for name, d in DFUNCS.items():
        where = 'dcmdH' if d['export'] else 'progD'
        print(f'  !{name}({", ".join(d["params"])})  [{where}]')

# ---------------- CMD: cmd commands ----------------
def CMD():
    mode('CMD: type a cmd command, Enter runs it (type endP~~ to exit)')
    while True:
        cmd = ask('cmd')
        if cmd.strip() == 'endP~~':
            break
        if cmd.strip():
            subprocess.run(cmd, shell=True)
    mode('CMD done')

def help_cmd():
    print('----------------------------------------------')
    print('write   create a file or folder')
    print('read    show a file')
    print('del     delete a file or folder')
    print('copy    copy a file or folder')
    print('dir     list a folder (blank = current folder)')
    print('dir/n   dir the current path')
    print('dir/H    list the whole computer (every drive)')
    print('cd      change current folder, e.g. cd C:\\Users')
    print('run     run a .py file')
    print('repcmd  repeat write/read/del N times')
    print('progP   run Python code (end with endP~~)')
    print('progD   run data codes: x=5, load, while, and/or/not, mk BC/LC (endP~~)')
    print('!f(x):  define a function in progD (body indented); @ line exports it to dcmdH')
    print('funcs   list your !functions')
    print('delfunc delete a !function (delfunc name)')
    print('CMD     run cmd commands (end with endP~~)')
    print('check   self-check: program integrity, exe version, memory')
    print('setup   re-run the installer')
    print('end     shutdown (/n now, /t after N sec, /q cancel)')
    print('end/n   shutdown now')
    print('ab')
    print('----------------------------------------------')

def credit():
    print('=============================================================')
    print('(C) Sunshine inc. All reserved. DO NOT COPY WITHOUT PERMISSION.')
    print('Text design ----- Desmond wu')
    print('Coding ---------- Desmond wu, DeepSeek Harness, doubao AI')
    print('Idea ------------ Desmond wu')
    print('=============================================================')

def about():
    base = Startup.app_home()
    vpath = os.path.join(base, 'Version.txt')
    if os.path.isfile(vpath):
        with open(vpath, encoding="utf-8") as f:
            V = f.read().strip()
    else:
        V = '5.1.0'
    has_exe = (bool(getattr(sys, 'frozen', False)) or
               os.path.isfile(os.path.join(base, 'dist', 'dcmdH', 'dcmdH.exe')))
    print(f'Sunshine DCMD-H [{("e" if has_exe else "") + V}]')
    if has_exe:
        info('There is dcmdH exe version.')
        info('version = e' + V)
    else:
        print('There is no dcmdH exe version.')
        info('version = ' + V)
    info('ecoding = UTF-8')
    print('(C) Sunshine inc. all reserved. DO NOT COPY WITHOUT PERMISSION.')

# ---------------- check: self-check ----------------
def _mem_status():
    """Return (total, available) physical memory in bytes, or (None, None)."""
    try:
        import ctypes
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ('dwLength', ctypes.c_ulong),
                ('dwMemoryLoad', ctypes.c_ulong),
                ('ullTotalPhys', ctypes.c_ulonglong),
                ('ullAvailPhys', ctypes.c_ulonglong),
                ('ullTotalPageFile', ctypes.c_ulonglong),
                ('ullAvailPageFile', ctypes.c_ulonglong),
                ('ullTotalVirtual', ctypes.c_ulonglong),
                ('ullAvailVirtual', ctypes.c_ulonglong),
                ('ullAvailExtendedVirtual', ctypes.c_ulonglong),
            ]
        s = MEMORYSTATUSEX()
        s.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s)):
            return int(s.ullTotalPhys), int(s.ullAvailPhys)
    except Exception:
        pass
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.total), int(vm.available)
    except Exception:
        pass
    try:
        with open('/proc/meminfo', encoding='utf-8') as f:
            d = {}
            for ln in f:
                if ':' in ln:
                    k, v = ln.split(':', 1)
                    d[k] = int(v.strip().split()[0]) * 1024
        if 'MemTotal' in d:
            return d['MemTotal'], d.get('MemAvailable', d.get('MemFree', 0))
    except Exception:
        pass
    return None, None


def _mem_str(n):
    if n is None:
        return 'unknown'
    if n < 1024:
        return f'{n} Bt'
    if n < 1024**2:
        return f'{n/1024:.2f} KB'
    if n < 1024**3:
        return f'{n/1024**2:.2f} MB'
    return f'{n/1024**3:.2f} GB'


def check():
    """Self-check: program integrity, exe version (if any), available memory."""
    mode('dcmdH self-check')
    print('=' * 92)
    frozen = bool(getattr(sys, 'frozen', False))
    base = Startup.app_home()

    # --- 1. program integrity ---
    checks = []
    if frozen:
        exe_path = os.path.abspath(sys.executable)
        checks += [
            ('dcmdH.exe', exe_path, 'file'),
            ('_internal', os.path.join(base, '_internal'), 'dir'),
            ('_internal/base_library.zip',
             os.path.join(base, '_internal', 'base_library.zip'), 'file'),
            ('_internal/python runtime dll',
             os.path.join(base, '_internal'), 'pydll'),
            ('Version.txt', os.path.join(base, 'Version.txt'), 'file'),
            ('dcmdH icon', exe_path, 'embedded'),
        ]
    else:
        exe_path = os.path.join(base, 'dist', 'dcmdH', 'dcmdH.exe')
        checks += [
            ('dcmdH.py', os.path.join(base, 'dcmdH.py'), 'file'),
            ('Startup.py', os.path.join(base, 'Startup.py'), 'file'),
            ('Version.txt', os.path.join(base, 'Version.txt'), 'file'),
            ('dcmdH icon.ico', os.path.join(base, 'dcmdH icon.ico'), 'file'),
        ]
        if os.path.isfile(exe_path):
            checks.append(('dist/dcmdH/dcmdH.exe', exe_path, 'file'))

    info('program integrity:')
    problems = []
    for label, path, kind in checks:
        if kind == 'embedded':
            print(f'  [OK] {label} (embedded in dcmdH.exe)')
            continue
        if kind == 'pydll':
            try:
                hits = sorted(n for n in os.listdir(path)
                              if re.match(r'python\d+\.dll$', n))
            except OSError:
                hits = []
            if hits:
                p = os.path.join(path, hits[0])
                print(f'  [OK] {label}: {hits[0]}  {size_str(p)}')
            else:
                problems.append(label)
                err(f'  missing {label} in {path}')
            continue
        if kind == 'dir':
            if os.path.isdir(path):
                try:
                    n = len(os.listdir(path))
                except OSError:
                    n = -1
                print(f'  [OK] {label}  ({n} item(s))')
            else:
                problems.append(label)
                err(f'  missing {label}')
            continue
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            print(f'  [OK] {label}  {size_str(path)}')
        else:
            problems.append(label)
            err(f'  missing or empty: {label}')

    # --- 2. version ---
    vpath = os.path.join(base, 'Version.txt')
    V = 'unknown'
    if os.path.isfile(vpath):
        try:
            with open(vpath, encoding='utf-8') as f:
                V = f.read().strip() or 'unknown'
        except OSError:
            pass
    print()
    info('version:')
    print(f'  source version = {V}')
    if os.path.isfile(exe_path):
        try:
            mtime = datetime.datetime.fromtimestamp(
                os.path.getmtime(exe_path)).strftime('%Y-%m-%d %H:%M')
        except OSError:
            mtime = 'unknown'
        print(f'  dcmdH exe version = e{V}')
        print(f'  exe path = {exe_path}')
        print(f'  exe size = {size_str(exe_path)}, built {mtime}')
    else:
        print('  There is no dcmdH exe version.')
        print('  (build one with: pyinstaller dcmdH.spec)')

    # --- 3. memory ---
    total, avail = _mem_status()
    print()
    info('memory:')
    print(f'  total physical   = {_mem_str(total)}')
    print(f'  available memory = {_mem_str(avail)}')
    if total and avail is not None:
        print(f'  used             = {100.0 * (total - avail) / total:.1f}%')

    print()
    if problems:
        err(f'self-check FAILED ({len(problems)} problem(s)): {", ".join(problems)}')
    else:
        ok('self-check passed: program files are intact.')
    print('=' * 92)

load_funcs()

print()
has_exe = (bool(getattr(sys, 'frozen', False)) or
           os.path.isfile(os.path.join(Startup.app_home(), 'dist', 'dcmdH', 'dcmdH.exe')))
if has_exe:
    info('version = e' + V)
    print(f'Sunshine DCMD-H [e{V}]')
else:
    info('version = ' + V)
    print(f'Sunshine DCMD-H [{V}]')
print('Made by Desmond wu from China, Macau s.a.')
print()
print(f'Started in: {cur}')

commands = {'write': write, 'read': read, 'del': delete, 'copy': copy, 'repcmd': rep,
            'dir': dir, 'dir/H': dir_h, 'run': run, 'cd': cd, 'setup': Startup.setup,
            'progP': progP, 'progD': progD, 'CMD': CMD, 'program': progP,
            'delfunc': delfunc, 'funcs': list_funcs,
            'help': help_cmd, 'end': shutdown, 'credit': credit,
            'dir/n': dirncur, 'end/n': shutdownn, 'about': about,'dezwu': dezwu,
            'check': check, 'selfcheck': check,}

def run_command(raw):
    """Run one dcmdH line: a main command, a user !function, or a progD data code."""
    cmd = raw.split(None, 1)[0] if raw.strip() else ''
    if cmd in commands:
        commands[cmd]()
        return
    fcm = re.match(r'(\w+)\s*\((.*)\)\s*$', raw.strip())
    if fcm and fcm.group(1) in DFUNCS and DFUNCS[fcm.group(1)]['export']:
        call_dfunc(fcm.group(1), fcm.group(2))
        return
    if cmd in DFUNCS and DFUNCS[cmd]['export']:
        call_dfunc(cmd, '')
        return
    # progD data codes work at the main prompt too (no progD wrapper needed):
    if raw.strip().lower().startswith('mk '):
        exec_data_statement(raw.strip())
        return
    ErrRaw = str(raw.strip())
    err(f"'{ErrRaw}' is not a valid command")

# one-shot mode:  dcmdH "mk LC with (1,2,3) t(abc)"  runs the data code and exits
if len(sys.argv) > 1:
    run_command(' '.join(sys.argv[1:]))
    sys.exit(0)
check()
while not shut:
    try:
        raw = input(f'{line} {prompt_path()}')
    except EOFError:
        break
    run_command(raw)
    line += 1
